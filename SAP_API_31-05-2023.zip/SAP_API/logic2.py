from app import *
import transactions
import scripts
from flask import request, jsonify, Blueprint
import pandas as pd
import time
from datetime import datetime, date, timedelta

import traceback

logic2 = Blueprint('logic2', __name__)


# def updateLogic2ScriptForShortList(scriptId, transactionFlag, _52wh, _10wl):
#     try:
#         sql = '{CALL UpdateLogic2Scripts(?, ?, ?, ?)}'
#         values = (scriptId, transactionFlag, _52wh, _10wl)
#         cursor.execute(sql, values)
#     except:
#         with open('errorLogs.txt', 'a+') as f:
#             f.writelines(f"{'='*10}{datetime.now()}{'='*10}")
#             traceback.print_exc(file=f)
def updateLogic2Scripts(scriptId, transactionFlag, _52WH, _10WL, qtyBalance, fundBalance, avgBuyPrice):
    try:
        cnxn = create_connection()
        cursor = cnxn.cursor()
        ################################################################################
        sql = ''  # need a sp here
################################################################################
        values = (scriptId, transactionFlag, _52WH, _10WL,
                  qtyBalance, fundBalance, avgBuyPrice)
        cursor.execute(sql, values)
        cnxn.close()
    except:
        with open('errorLogs.txt', 'a+') as f:
            f.writelines(f"{'='*10}{datetime.now()}{'='*10}")
            traceback.print_exc(file=f)


def insertLogic2Transaction(scriptId, orderType, qtySlab, qtyBalance, profit, transactionPrice, scriptFundBalance):
    try:
        cnxn = create_connection()
        cursor = cnxn.cursor()
        sql = '{CALL insertLogic2Transactions(?,?,?,?,?,?,? )}'
        values = (scriptId, orderType, qtySlab,
                  qtyBalance, profit, transactionPrice, scriptFundBalance)
        cursor.execute(sql, values)
        cnxn.close()
    except:
        with open('errorLogs.txt', 'a+') as f:
            f.writelines(f"{'='*10}{datetime.now()}{'='*10}")
            traceback.print_exc(file=f)


def get52WHprice(priceList):
    max = 0
    for x in priceList:
        if x[2] >= max:
            max = x[2]
    return max


def get10WLprice(priceList):
    min = 9999999999
    for x in priceList:
        if x[3] <= min:
            min = x[3]
    return min


def deleteLogic2ScriptById(id, scriptName, qty):
    try:
        # order_status = placeorder(scriptName, -1, qty)
        # if order_status['s'] != 'error':
        cnxn = create_connection()
        cursor = cnxn.cursor()
        sql = '{CALL DeleteLogic2Script(?)}'
        values = (id)
        cursor.execute(sql, values)
        cnxn.commit()
        cnxn.close()
        # else:
        #     createLog(order_status['message'], scriptName)

    except:
        with open('errorLogs.txt', 'a+') as f:
            f.writelines(f"{'='*10}{datetime.now()}{'='*10}")
            traceback.print_exc(file=f)


def updateLogic2ScriptCurrentPriceById(id, current_price, deal):
    try:
        cnxn = create_connection()
        cursor = cnxn.cursor()
        sql = '{CALL updateCurrentPriceByLogic2ScriptId(?, ?, ?)}'
        values = (id, current_price, deal)
        cnxn.execute(sql, values)
        cnxn.commit()
        cnxn.close()
    except:
        with open('errorLogs.txt', 'a+') as f:
            f.writelines(f"{'='*10}{datetime.now()}{'='*10}")
            traceback.print_exc(file=f)


def Update52WHand10WL(id, _52WH, _10WL):
    try:
        cnxn = create_connection()
        cursor = cnxn.cursor()
        sql = '{CALL Update52WHand10WL(?, ?, ?)}'
        values = (id, _52WH, _10WL)
        cnxn.execute(sql, values)
        cnxn.commit()
        cnxn.close()
    except:
        with open('errorLogs.txt', 'a+') as f:
            f.writelines(f"{'='*10}{datetime.now()}{'='*10}")
            traceback.print_exc(file=f)


def updateLogic2ScriptCurrentPriceById(id, current_price, deal):
    try:
        cnxn = create_connection()
        cursor = cnxn.cursor()
        sql = '{CALL updateCurrentPriceByLogic2ScriptId(?, ?, ?)}'
        values = (id, current_price, deal)
        cnxn.execute(sql, values)
        cnxn.commit()
        cnxn.close()
    except:
        with open('errorLogs.txt', 'a+') as f:
            f.writelines(f"{'='*10}{datetime.now()}{'='*10}")
            traceback.print_exc(file=f)
# edit logic 2 function


def UpdateLogic2ScriptById(id, buyMargin, sellMargin):
    try:
        cnxn = create_connection()
        cursor = cnxn.cursor()
        sql = '{CALL editLogic2ScriptForm(?, ?, ?)}'
        values = (id, buyMargin,
                  sellMargin)
        cnxn.execute(sql, values)
        cnxn.commit()
        cnxn.close()
    except:
        with open('errorLogs.txt', 'a+') as f:
            f.writelines(f"{'='*10}{datetime.now()}{'='*10}")
            traceback.print_exc(file=f)


def getLastTransaction(id):
    try:
        # create a sp with query
        # select top 1 transaction_price from logic2scripts where script_id = @id order by order_date desc
        cnxn = create_connection()
        cursor = cnxn.cursor()
        sql = '{CALL getLastTransaction(?)}'
        values = (id)
        cnxn.execute(sql, values)
        cnxn.commit()
        cnxn.close()
    except:
        with open('errorLogs.txt', 'a+') as f:
            f.writelines(f"{'='*10}{datetime.now()}{'='*10}")
            traceback.print_exc(file=f)


@logic2.route('/Updatelogic2ScriptById', methods=['PUT'])
@token_required
def Update_Logic2_Script_By_Id():

    content_type = request.headers.get('Content-Type')
    if (content_type == 'application/json'):
        json = request.json
        print(json)
    else:
        return 'Content-Type not supported!'
    try:
        buyMargin = json["buy_Margin"]
        sellMargin = json["sell_Margin"]
        # investmentAmount = json["investmentAmount"]
        id = json["id"]
        UpdateLogic2ScriptById(id, buyMargin, sellMargin)
    #    UpdateSellBuyMargin(id, sellMargin)
        return jsonify("Success")
    except:
        with open('errorLogs.txt', 'a+') as f:
            f.writelines(f"{'='*10}{datetime.now()}{'='*10}")
            traceback.print_exc(file=f)
            return jsonify({"message": str("500: Internal Server Error")}), 500


@logic2.route('/InsertLogic2Script', methods=['POST'])
@token_required
def insert_scripts():

    content_type = request.headers.get('Content-Type')
    if (content_type == 'application/json'):
        json = request.json
        # print(json)
    else:
        return 'Content-Type not supported!'
    try:
        cnxn = create_connection()
        cursor = cnxn.cursor()
        cursor.execute(
            f"select *from logic2scripts where script_name = '{json['selectedScript']['code']}'")
        result = cursor.fetchone()
        cnxn.close()
        if result == None:
            data = {"symbols": f"NSE:{json['selectedScript']['code']}-EQ"}
            current_price = fyers.quotes(data)["d"][0]["v"]["lp"]
            eligibility_quantity = int(
                float(json['investmentAmount'])/current_price)
            qty_slab = int(eligibility_quantity/5)
            startDate = date.today() - timedelta(days=365)
            endDate = date.today() - timedelta(days=1)
            dataFor52WH = {
                "symbol": f"NSE:{json['selectedScript']['code']}-EQ",
                "resolution": "D",
                "date_format": "1",
                "range_from": startDate,
                "range_to": endDate,
                "cont_flag": "1"
            }
            _52wh = get52WHprice(fyers.history(data=dataFor52WH)['candles'])
            startDate = date.today() - timedelta(days=70)
            endDate = date.today() - timedelta(days=1)
            dataFor10WL = {
                "symbol": f"NSE:{json['selectedScript']['code']}-EQ",
                "resolution": "D",
                "date_format": "1",
                "range_from": startDate,
                "range_to": endDate,
                "cont_flag": "1"
            }
            _10wl = get10WLprice(fyers.history(data=dataFor10WL)['candles'])
            sql = '{CALL insertlogic2Scripts(?, ?, ?, ?, ?, ?, ?,?)}'
            values = (json['selectedScript']['code'],
                      json['investmentAmount'], json['buy_margin'],  json['sell_margin'], qty_slab, _52wh, _10wl, current_price)
            cursor.execute(sql, values)
            cursor.commit()

            return jsonify("Success")

        else:
            return jsonify({"message": f"{json['selectedScript']['code']} is already added!"})
    except Exception as e:
        with open('errorLogs.txt', 'a+') as f:
            f.writelines(f"{'='*10}{datetime.now()}{'='*10}")
            traceback.print_exc(file=f)
            return jsonify({"messge": str(e)})


@logic2.route('/getAllLogic2Scripts', methods=['GET'])
@token_required
def getallscriptsforlogic2():
    try:
        cnxn = create_connection()
        cursor = cnxn.cursor()
        columns = ['id', 'scriptName', 'transactionFlag', '_52wh', '_10wl',
                   'avgBuyPrice', 'qtyBalance', 'isdeleted', 'investedAmount', 'investmentBalance', 'qtySlab', 'ModifiedDate', 'buyMargin', 'sellMargin', 'currentPrice', 'deal']
        cursor.execute('select * from logic2scripts')
        result = []
        for row in cursor.fetchall():
            result.append(dict(zip(columns, row)))
        cnxn.close()
        return jsonify(result)
    except:
        with open('errorLogs.txt', 'a+') as f:
            f.writelines(f"{'='*10}{datetime.now()}{'='*10}")
            traceback.print_exc(file=f)
            return jsonify({"message": str("500: Internal Server Error")}), 500


@logic2.route('/GetLogic2ScriptById/<id>', methods=['GET'])
@token_required
def getLogic2ScriptById(id):
    try:
        cnxn = create_connection()
        cursor = cnxn.cursor()
        columns = ['id', 'scriptName', 'transactionFlag', '_52wh', '_10wl',
                   'avgBuyPrice', 'qtyBalance', 'isdeleted', 'investedAmount', 'investmentBalance',     'qtySlab', 'ModifiedDate', 'buyMargin', 'sellMargin', 'currentPrice', 'deal']
        cursor.execute(f"select * from logic2scripts where id = {id}")
        result = cursor.fetchone()
        # result[16] = float(result[16])
        result = (dict(zip(columns, result)))
        cnxn.close()
        return jsonify(result)
    except:
        with open('errorLogs.txt', 'a+') as f:
            f.writelines(f"{'='*10}{datetime.now()}{'='*10}")
            traceback.print_exc(file=f)
            return jsonify({"message": str("500: Internal Server Error")}), 500


@logic2.route('/getLogic2TransactionById/<id>', methods=['GET'])
@token_required
def GetLogic2TransactionByScriptId(id):
    try:
        result = []
        cnxn = create_connection()
        cursor = cnxn.cursor()
        columns = ['transactionId', 'scriptName', 'orderDate', 'orderType', 'qtySlab',
                   'qtyBalance', 'scriptFundBalance', 'profit', 'transactionPrice']
        sql = '{CALL getLogic2TransactionsById(?)}'
        values = (id)
        cursor.execute(sql, values)
        for row in cursor.fetchall():
            result.append(dict(zip(columns, row)))
        cnxn.close()
        return jsonify(result)
    except:
        with open('errorLogs.txt', 'a+') as f:
            f.writelines(f"{'='*10}{datetime.now()}{'='*10}")
            traceback.print_exc(file=f)
            return jsonify({"message": str("500: Internal Server Error")}), 500


@logic2.route('/DeleteLogic2ScriptById', methods=['DELETE'])
@token_required
def deleteLogic2ScriptById():
    try:
        args = request.args
        id = args.to_dict()["id"]
        scriptName = args.to_dict()["scriptName"]
        qty = args.to_dict()["qty"]
        print("id:", id, "qty:", qty, "scriptName:",
              scriptName)
        # data = {"symbols": f"NSE:{scriptName}-EQ"}
        # print(fyers.quotes(data))
        # if (fyers.quotes(data)):
        # current_price = fyers.quotes(data)["d"][0]["v"]["lp"]
        if int(qty) == 0:
            print("Delete")
            cnxn = create_connection()
            cursor = cnxn.cursor()
            sql = '{CALL DeleteLogic2Script(?)}'
            values = (id)
            cursor.execute(sql, values)
            cnxn.commit()
            cnxn.close()
        # else:
        #     print("current price", current_price)
        #     # print("last transaction", app.last_transaction)
        #     print("qty", qty)
        #     avg_price = getAvgPriceByScriptId(id)
        #     transactions.insert_transactions(
        #         id, -1, qty, 0, 0, 0, 0, (float(current_price) - float(avg_price))*float(qty), 0, 0, 0, 0, 0)
        #     updateScript(id, 0, 0, current_price, 0, 0)
        #     deleteLogic2ScriptById(id, scriptName, qty)
        #     createTransctionLog(
        #         f"Sold {qty} of {scriptName} (Delete)", scriptName)

        return jsonify("Success")
    except:
        with open('errorLogs.txt', 'a+') as f:
            f.writelines(f"{'='*10}{datetime.now()}{'='*10}")
            traceback.print_exc(file=f)
            return jsonify({"message": "Internal Server Error"}), 500
# This route runs at a time interval everyday to check which condition is met (buy, loss sell, profit sell) No transactions are made here


@logic2.route("/updateLogic2ScriptsCurrentPrice", methods=["GET"])
@token_required
def update_script_current_price_by_id():
    try:
        cnxn = create_connection()
        cursor = cnxn.cursor()
        columns = ['id', 'quantityBalance', 'avgPrice', 'deal', 'scriptName']
        cursor.execute(
            'select id,avg_price,quantity_balance,deal,script_name from logic2Scripts where isdeleted = 0')
        result = []
        for row in cursor.fetchall():
            result.append(dict(zip(columns, row)))
        cnxn.close()
        for row in result:
            data = {"symbols": f"NSE:{row['scriptName']}-EQ"}
            current_price = fyers.quotes(data)["d"][0]["v"]["lp"]
            # print(fyers.quotes(data))
            avg_price = float(row["avgPrice"])
            qty = float(row["quantityBalance"])
            deal = (current_price - avg_price)*qty
            updateLogic2ScriptCurrentPriceById(row["id"], current_price, deal)
            time.sleep(1)

        return jsonify("Updated")
    except:
        with open('errorLogs.txt', 'a+') as f:
            f.writelines(f"{'='*10}{datetime.now()}{'='*10}")
            # f.writelines(str(fyers.quotes(data)))
            traceback.print_exc(file=f)
            return jsonify({"message": "Internal Server Error"}), 500


@ logic2.route('/Logic2Transaction', methods=['GET'])
@ token_required
def start_program():
    transactionList = []
    # get all the active scripts for Logic2
    cnxn2 = pyodbc.connect(cnxn_str)
    cursor2 = cnxn2.cursor()
    activeScripts = cursor2.execute(
        f"select * from logic2Scripts where isdeleted = 0").fetchall()
    if (datetime.now() < datetime.now().replace(hour=15, minute=30, second=0, microsecond=0) and activeScripts != None):
        for rowdata in activeScripts:
            # need to change the index values [] after database is build
            id = rowdata[0]
            scriptName = rowdata[1]
            transactionFlag = rowdata[2]
            avgBuyPrice = rowdata[6]
            quantityBalance = rowdata[7]
            fundBalance = rowdata[8]
            investmentAmount = rowdata[9]
            qtySlab = rowdata[10]
            buyMargin = [11]  # Need to change this as per column in
            # Table also update in sp and route For both Insert and get route
            sellMargin = [12]
            lastTransaction = getLastTransaction(id)  # -> Get Last Buy Price
            stopLoss = rowdata[13]
            data = {"symbols": f"NSE:{rowdata[1]}-EQ"}
            currentPrice = float(fyers.quotes(data)["d"][0]["v"]["lp"])
            startDate = date.today() - timedelta(days=365)
            endDate = date.today() - timedelta(days=1)
            dataFor52WH = {
                "symbol": f"NSE:SBIN-EQ",
                "resolution": "D",
                "date_format": "1",
                "range_from": startDate,
                "range_to": endDate,
                "cont_flag": "1"
            }
            _52wh = get52WHprice(fyers.history(data=dataFor52WH)['candles'])
            startDate = datetime.date.today() - datetime.timedelta(days=70)
            endDate = date.today() - timedelta(days=1)
            dataFor10WL = {
                "symbol": f"NSE:SBIN-EQ",
                "resolution": "D",
                "date_format": "1",
                "range_from": startDate,
                "range_to": endDate,
                "cont_flag": "1"
            }
            _10wl = get10WLprice(fyers.history(data=dataFor10WL)['candles'])

            current_day = datetime.datetime.now().weekday()
            _320pm = datetime.now().replace(
                hour=15, minute=20, second=0, microsecond=0)
            _330pm = datetime.datetime.now().replace(
                hour=15, minute=30, second=0, microsecond=0)
            curent_time = datetime.datetime.now().strftime('%H:%M:%S')
            if currentPrice > _52wh and quantityBalance == 0:
                updateLogic2Scripts(id, 1, _52wh, _10wl,
                                    quantityBalance, fundBalance, avgBuyPrice)
            # inital buy stocks on friday between 3:20 and 3:30 pm
            if quantityBalance == 0 and transactionFlag == 1 and current_day == 5 and curent_time > _320pm and curent_time < _330pm:
                order_status = buy_order(scriptName, qtySlab)
                if order_status['s'] != 'error':
                    quantityBalance += qtySlab
                    fundBalance -= currentPrice*qtySlab
                    avgBuyPrice = (investmentAmount -
                                   fundBalance)/quantityBalance
                    print("print buy qty slab")
                    insertLogic2Transaction(
                        id,
                        1,
                        qtySlab,
                        quantityBalance,
                        0,
                        currentPrice
                    )
                    updateLogic2Scripts(
                        id, 0, _52wh, _10wl, quantityBalance, fundBalance, avgBuyPrice)
                else:
                    createLog(order_status['message'], scriptName)
                    transactionList.append(
                        {"scriptName": scriptName, "message": order_status['message']})
            # buy stocks if cp is buyMargin% down of last transaction
            if quantityBalance > 0 and currentPrice < lastTransaction - (buyMargin/100)*lastTransaction and fundBalance >= qtySlab*currentPrice:
                order_status = buy_order(scriptName, qtySlab)
                if order_status['s'] != 'error':
                    quantityBalance += qtySlab
                    fundBalance -= currentPrice*qtySlab
                    avgBuyPrice = (investmentAmount -
                                   fundBalance)/quantityBalance
                    print("print buy qty slab")
                    insertLogic2Transaction(
                        id,
                        1,
                        qtySlab,
                        quantityBalance,
                        0,
                        currentPrice
                    )
                    updateLogic2Scripts(
                        id, 0, _52wh, _10wl, quantityBalance, fundBalance, avgBuyPrice)
                else:
                    createLog(order_status['message'], scriptName)
                    transactionList.append(
                        {"scriptName": scriptName, "message": order_status['message']})
            # sell all stocks at loss
            if currentPrice < _10wl or (currentPrice < avgBuyPrice - stopLoss/100*avgBuyPrice and avgBuyPrice != 0):
                order_status = sell_order(scriptName, quantityBalance)
                if order_status['s'] != 'error':
                    qtySlab = quantityBalance
                    quantityBalance = 0
                    fundBalance += avgBuyPrice*qtySlab
                    print("print buy qty slab")
                    insertLogic2Transaction(
                        id,
                        1,
                        qtySlab,
                        quantityBalance,
                        (currentPrice - avgBuyPrice)*qtySlab,
                        currentPrice
                    )
                    updateLogic2Scripts(id, 0, _52wh, _10wl,
                                        quantityBalance, fundBalance, 0)
                else:
                    createLog(order_status['message'], scriptName)
                    transactionList.append(
                        {"scriptName": scriptName, "message": order_status['message']})
            # sell all stocks at profit
            if currentPrice > avgBuyPrice + sellMargin/100*avgBuyPrice and avgBuyPrice != 0:
                order_status = sell_order(scriptName, qtySlab)
                if order_status['s'] != 'error':
                    qtySlab = quantityBalance
                    quantityBalance = 0
                    fundBalance += avgBuyPrice*qtySlab
                    insertLogic2Transaction(
                        id,
                        1,
                        qtySlab,
                        quantityBalance,
                        (currentPrice - avgBuyPrice)*qtySlab,
                        currentPrice
                    )
                    updateLogic2Scripts(id, 0, _52wh, _10wl,
                                        quantityBalance, fundBalance, 0)
                else:
                    createLog(order_status['message'], scriptName)
                    transactionList.append(
                        {"scriptName": scriptName, "message": order_status['message']})
    return jsonify("success")


# @ logic2.route('/test52wh', methods=['GET'])
# def test():
#     startDate = datetime.date.today() - datetime.timedelta(days=365)
#     endDate = datetime.date.today() - datetime.timedelta(days=1)
#     dataFor52WH = {
#         "symbol": f"NSE:SBIN-EQ",
#         "resolution": "D",
#         "date_format": "1",
#         "range_from": startDate,
#         "range_to": endDate,
#         "cont_flag": "1"
#     }
#     _52wh = get52WHprice(fyers.history(data=dataFor52WH)['candles'])
#     return jsonify(_52wh)

#
# @ logic2.route('/test10wl', methods=['GET'])
# def test10wl():
#     startDate = datetime.date.today() - datetime.timedelta(days=70)
#     endDate = datetime.date.today() - datetime.timedelta(days=1)
#     dataFor10WL = {
#         "symbol": f"NSE:SBIN-EQ",
#         "resolution": "D",
#         "date_format": "1",
#         "range_from": startDate,
#         "range_to": endDate,
#         "cont_flag": "1"
#     }
#     _10wl = get10WLprice(fyers.history(data=dataFor10WL)['candles'])
#     return jsonify(_10wl)


def getAllCodes():
    try:
        symbolDataLink = "ind_nifty100list.csv"
        symbolData = pd.read_csv(symbolDataLink)
        scriptCode = []
        for data in symbolData.iterrows():
            scriptCode.append(data[1][2])
        return scriptCode
    except Exception as e:
        with open('errorLogs.txt', 'a+') as f:
            f.writelines(f"{'='*10}{datetime.now()}{'='*10}")
            traceback.print_exc(file=f)
            return jsonify("Error", e), 500


@ logic2.route('/GetAllScriptCodeForNifty100', methods=["GET"])
@token_required
def getAllScriptsCode():
    try:
        scriptCodeList = []
        scriptCodes = getAllCodes()
        for script in scriptCodes:
            scriptCodeList.append({"name": script, "code": script})
        return scriptCodeList
    except:
        with open('errorLogs.txt', 'a+') as f:
            f.writelines(f"{'='*10}{datetime.now()}{'='*10}")
            traceback.print_exc(file=f)
            return jsonify({"message": str("500: Internal Server Error")}), 500
