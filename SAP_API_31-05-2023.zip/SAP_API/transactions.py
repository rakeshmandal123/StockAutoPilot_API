from app import app, create_connection, token_required
from flask import request, jsonify, Blueprint
import pandas as pd
import traceback
from datetime import datetime

# function for insert transaction
transaction = Blueprint('transaction', __name__)


def insert_transactions(scriptId, orderType, qtySlab, buyTarget, sellTarget, qtyBalance, scriptFundBalance, Profit, buyRate, Bings, buyMargin, sellMargin, sm2sell):
    try:
        cnxn = create_connection()
        cursor = cnxn.cursor()
        sql = '{CALL InsertTransaction(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}'
        values = (scriptId, orderType, qtySlab, buyTarget, sellTarget,
                  qtyBalance, scriptFundBalance, Profit, buyRate, Bings, buyMargin, sellMargin, sm2sell)
        cursor.execute(sql, values)
        cursor.commit()
        cnxn.close()
    except:
        with open('errorLogs.txt', 'a+') as f:
            f.writelines(f"{'='*10}{datetime.now()}{'='*10}")
            traceback.print_exc(file=f)

# get transaction by id


def GetTransactionByScriptId(Id):
    try:
        cnxn = create_connection()
        cursor = cnxn.cursor()
        sql = '{CALL getAlltransactions(?)}'
        values = (Id)
        cursor.execute(sql, values)
        row = cursor.fetchone()
        cnxn.close()
        return row
    except:
        with open('errorLogs.txt', 'a+') as f:
            f.writelines(f"{'='*10}{datetime.now()}{'='*10}")
            traceback.print_exc(file=f)


def getTodaysProfit():
    try:
        cnxn = create_connection()
        cursor = cnxn.cursor()
        sql = '{CALL getTodaysProfit()}'
        cursor.execute(sql)
        result = cursor.fetchone()
        cnxn.close()
        return result[0]
    except:
        with open('errorLogs.txt', 'a+') as f:
            f.writelines(f"{'='*10}{datetime.now()}{'='*10}")
            traceback.print_exc(file=f)

# Route to  get transaction by id


@transaction.route('/getTransactionById/<id>', methods=['GET'])
@token_required
def GetTransactionByScriptId(id):
    try:
        result = []
        cnxn = create_connection()
        cursor = cnxn.cursor()
        columns = ['transactionId', 'scriptName', 'orderDate', 'orderType', 'qtySlab', 'buyTarget', 'sellTarget',
                   'qtyBalance', 'scriptFundBalance', 'profit', 'buyRate', 'buyMargin', 'sellMargin', 'sellId']
        sql = '{CALL GetTransactionByScriptId(?)}'
        values = (id)
        cursor.execute(sql, values)
        for row in cursor.fetchall():
            result.append(dict(zip(columns, row)))
        cnxn.close()
        return jsonify(result)
    except:
        with open('errorLogs.txt', 'a+') as f:
            f.writelines(f"{'='*10}{datetime.now()}{'='*10}")
            traceback.print_exc(file=f)
            return jsonify({"message": str("500: Internal Server Error")}), 500


@transaction.route('/getTodaysProfit', methods=['GET'])
@token_required
def getTodaysProfit():
    try:
        cnxn = create_connection()
        cursor = cnxn.cursor()
        sql = '{CALL getTodaysProfit()}'
        cursor.execute(sql)
        result = cursor.fetchone()
        cnxn.close()
        return jsonify(result[0])
    except:
        with open('errorLogs.txt', 'a+') as f:
            f.writelines(f"{'='*10}{datetime.now()}{'='*10}")
            traceback.print_exc(file=f)
            return jsonify({"message": str("500: Internal Server Error")}), 500


@transaction.route('/GetTransactionForCurrentDate', methods=['GET'])
@token_required
def transactionForCurrentDate():
    try:
        result = []
        cnxn = create_connection()
        cursor = cnxn.cursor()
        columns = ['scriptId', 'scriptName', 'orderDate', 'orderType', 'qtySlab', 'buyTarget', 'sellTarget',
                   'qtyBalance', 'scriptFundBalance', 'profit', 'buyRate', 'sm2sell']
        sql = '{CALL getAlltransactions()}'
        cursor.execute(sql)
        for row in cursor.fetchall():
            result.append(dict(zip(columns, row)))
        cnxn.close()
        return jsonify(result)
    except:
        with open('errorLogs.txt', 'a+') as f:
            f.writelines(f"{'='*10}{datetime.now()}{'='*10}")
            traceback.print_exc(file=f)
            return jsonify({"message": str("500: Internal Server Error")}), 500
